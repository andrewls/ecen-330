/*
 * utils.h
 *
 *  Created on: Jul 18, 2014
 *      Author: hutch
 */

#ifndef UTILS_H_
#define UTILS_H_

void utils_msDelay(long ms);
void utils_microsecondDelay(long microSecondDelay);

#endif /* UTILS_H_ */
